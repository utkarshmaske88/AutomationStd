define(['brease/core/designer/BaseWidget/ClassInfo'], function () {

    'use strict';

    return {
        
    };
});
