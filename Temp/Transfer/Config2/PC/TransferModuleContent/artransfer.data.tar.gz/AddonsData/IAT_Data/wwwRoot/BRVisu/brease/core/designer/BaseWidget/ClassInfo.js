define(['brease/core/designer/BaseWidget/ClassExtension'], function () {

    'use strict';

    return {

    };
});
